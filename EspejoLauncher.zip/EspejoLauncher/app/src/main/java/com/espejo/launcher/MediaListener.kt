package com.espejo.launcher

import android.service.notification.NotificationListenerService

// Solo sirve para que Android permita leer la música que se está reproduciendo.
class MediaListener : NotificationListenerService()
